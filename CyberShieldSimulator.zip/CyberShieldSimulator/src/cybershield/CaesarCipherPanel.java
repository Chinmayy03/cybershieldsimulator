package cybershield;

import javax.swing.*;
import java.awt.*;

public class CaesarCipherPanel extends JPanel {
    public CaesarCipherPanel() {
        setLayout(new BorderLayout());
        setBackground(UIUtils.DARK_BG);

        JLabel title = new JLabel("Caesar Cipher Tool");
        title.setFont(UIUtils.FONT_TITLE);
        title.setForeground(UIUtils.DARK_FG);
        title.setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));
        add(title, BorderLayout.NORTH);

        JPanel centerPanel = new JPanel(new GridBagLayout());
        centerPanel.setBackground(UIUtils.DARK_BG);
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(10, 10, 10, 10);
        gbc.fill = GridBagConstraints.HORIZONTAL;

        JLabel lbl = new JLabel("Enter Text:");
        lbl.setForeground(UIUtils.DARK_FG);
        lbl.setFont(UIUtils.FONT_HEADING);
        gbc.gridx = 0; gbc.gridy = 0;
        centerPanel.add(lbl, gbc);

        JTextArea inputArea = new JTextArea(4, 30);
        inputArea.setFont(UIUtils.FONT_NORMAL);
        inputArea.setBackground(new Color(50, 50, 60));
        inputArea.setForeground(UIUtils.DARK_FG);
        inputArea.setCaretColor(UIUtils.DARK_FG);
        inputArea.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(UIUtils.PRIMARY_COLOR, 1),
                BorderFactory.createEmptyBorder(5, 10, 5, 10)
        ));
        gbc.gridx = 0; gbc.gridy = 1; gbc.gridwidth = 2;
        centerPanel.add(new JScrollPane(inputArea), gbc);

        JLabel shiftLbl = new JLabel("Shift Value (1-25):");
        shiftLbl.setForeground(UIUtils.DARK_FG);
        shiftLbl.setFont(UIUtils.FONT_NORMAL);
        gbc.gridx = 0; gbc.gridy = 2; gbc.gridwidth = 1;
        centerPanel.add(shiftLbl, gbc);

        JSpinner shiftSpinner = new JSpinner(new SpinnerNumberModel(3, 1, 25, 1));
        gbc.gridx = 1; gbc.gridy = 2;
        centerPanel.add(shiftSpinner, gbc);

        JButton encryptBtn = new JButton("Encrypt \uD83D\uDD12");
        UIUtils.styleButton(encryptBtn, UIUtils.PRIMARY_COLOR);
        gbc.gridx = 0; gbc.gridy = 3; gbc.gridwidth = 1;
        centerPanel.add(encryptBtn, gbc);

        JButton decryptBtn = new JButton("Decrypt \uD83D\uDD13");
        UIUtils.styleButton(decryptBtn, UIUtils.WARNING_COLOR);
        gbc.gridx = 1; gbc.gridy = 3;
        centerPanel.add(decryptBtn, gbc);

        JLabel resLbl = new JLabel("Result:");
        resLbl.setForeground(UIUtils.DARK_FG);
        resLbl.setFont(UIUtils.FONT_HEADING);
        gbc.gridx = 0; gbc.gridy = 4; gbc.gridwidth = 2;
        centerPanel.add(resLbl, gbc);

        JTextArea resultArea = new JTextArea(4, 30);
        resultArea.setEditable(false);
        resultArea.setFont(UIUtils.FONT_NORMAL);
        resultArea.setBackground(new Color(40, 40, 50));
        resultArea.setForeground(new Color(0, 255, 0));
        resultArea.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));
        gbc.gridx = 0; gbc.gridy = 5;
        centerPanel.add(new JScrollPane(resultArea), gbc);

        encryptBtn.addActionListener(e -> {
            String text = inputArea.getText();
            int shift = (int) shiftSpinner.getValue();
            resultArea.setText(processCipher(text, shift, true));
            ActivityLog.log("Encrypted text with Caesar Cipher (shift: " + shift + ")");
        });

        decryptBtn.addActionListener(e -> {
            String text = inputArea.getText();
            int shift = (int) shiftSpinner.getValue();
            resultArea.setText(processCipher(text, shift, false));
            ActivityLog.log("Decrypted text with Caesar Cipher (shift: " + shift + ")");
        });

        add(centerPanel, BorderLayout.CENTER);
    }

    private String processCipher(String text, int shift, boolean encrypt) {
        StringBuilder result = new StringBuilder();
        if (!encrypt) {
            shift = 26 - (shift % 26);
        }

        for (char ch : text.toCharArray()) {
            if (Character.isUpperCase(ch)) {
                char c = (char) (((int) ch + shift - 65) % 26 + 65);
                result.append(c);
            } else if (Character.isLowerCase(ch)) {
                char c = (char) (((int) ch + shift - 97) % 26 + 97);
                result.append(c);
            } else {
                result.append(ch);
            }
        }
        return result.toString();
    }
}

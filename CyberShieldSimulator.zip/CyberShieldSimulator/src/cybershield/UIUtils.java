package cybershield;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import java.awt.*;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;

public class UIUtils {
    public static boolean isDarkMode = true;

    // Dark Theme Colors
    public static final Color DARK_BG = new Color(30, 30, 36);
    public static final Color DARK_SIDEBAR = new Color(43, 43, 54);
    public static final Color DARK_FG = new Color(240, 240, 240);
    public static final Color PRIMARY_COLOR = new Color(76, 175, 80); // Green
    public static final Color DANGER_COLOR = new Color(244, 67, 54); // Red
    public static final Color WARNING_COLOR = new Color(255, 152, 0); // Orange

    public static final Font FONT_TITLE = new Font("Segoe UI", Font.BOLD, 28);
    public static final Font FONT_HEADING = new Font("Segoe UI", Font.BOLD, 18);
    public static final Font FONT_NORMAL = new Font("Segoe UI", Font.PLAIN, 14);

    public static void styleButton(JButton button, Color bg) {
        button.setBackground(bg);
        button.setForeground(Color.WHITE);
        button.setFont(FONT_HEADING);
        button.setFocusPainted(false);
        button.setBorder(new EmptyBorder(10, 20, 10, 20));
        button.setCursor(new Cursor(Cursor.HAND_CURSOR));
        
        button.addMouseListener(new MouseAdapter() {
            public void mouseEntered(MouseEvent evt) {
                button.setBackground(bg.brighter());
            }
            public void mouseExited(MouseEvent evt) {
                button.setBackground(bg);
            }
        });
    }

    public static void styleSidebarButton(JButton button) {
        button.setBackground(DARK_SIDEBAR);
        button.setForeground(DARK_FG);
        button.setFont(FONT_HEADING);
        button.setFocusPainted(false);
        button.setBorder(new EmptyBorder(15, 20, 15, 20));
        button.setHorizontalAlignment(SwingConstants.LEFT);
        button.setCursor(new Cursor(Cursor.HAND_CURSOR));

        button.addMouseListener(new MouseAdapter() {
            public void mouseEntered(MouseEvent evt) {
                button.setBackground(new Color(60, 60, 75));
            }
            public void mouseExited(MouseEvent evt) {
                button.setBackground(DARK_SIDEBAR);
            }
        });
    }

    public static void styleTextField(JTextField textField) {
        textField.setFont(FONT_NORMAL);
        textField.setBackground(new Color(50, 50, 60));
        textField.setForeground(DARK_FG);
        textField.setCaretColor(DARK_FG);
        textField.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(PRIMARY_COLOR, 1),
                BorderFactory.createEmptyBorder(8, 10, 8, 10)
        ));
    }
}

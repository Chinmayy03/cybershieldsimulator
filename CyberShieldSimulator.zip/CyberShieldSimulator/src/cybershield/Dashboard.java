package cybershield;

import javax.swing.*;
import java.awt.*;

public class Dashboard extends JFrame {
    private JPanel contentPanel;
    private CardLayout cardLayout;

    public Dashboard() {
        setTitle("CyberShield Simulator - Dashboard");
        setSize(900, 600);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        
        setLayout(new BorderLayout());

        // Sidebar
        JPanel sidebar = new JPanel();
        sidebar.setBackground(UIUtils.DARK_SIDEBAR);
        sidebar.setLayout(new BoxLayout(sidebar, BoxLayout.Y_AXIS));
        sidebar.setPreferredSize(new Dimension(250, 600));

        JLabel titleLabel = new JLabel("CyberShield");
        titleLabel.setFont(new Font("Segoe UI", Font.BOLD, 24));
        titleLabel.setForeground(UIUtils.PRIMARY_COLOR);
        titleLabel.setAlignmentX(Component.CENTER_ALIGNMENT);
        titleLabel.setBorder(BorderFactory.createEmptyBorder(20, 10, 30, 10));
        sidebar.add(titleLabel);

        // Card Layout for main content
        cardLayout = new CardLayout();
        contentPanel = new JPanel(cardLayout);
        contentPanel.setBackground(UIUtils.DARK_BG);

        // Add modules to card layout
        contentPanel.add(new PasswordCheckerPanel(), "Password");
        contentPanel.add(new PhishingDetectorPanel(), "Phishing");
        contentPanel.add(new OTPGeneratorPanel(), "OTP");
        contentPanel.add(new CaesarCipherPanel(), "Caesar");
        contentPanel.add(ActivityLog.getLogPanel(), "Activity");

        // Sidebar Buttons
        sidebar.add(createSidebarBtn("Password Strength \uD83D\uDD11", "Password")); // Key
        sidebar.add(Box.createRigidArea(new Dimension(0, 10)));
        sidebar.add(createSidebarBtn("Phishing Detector \uD83D\uDD0D", "Phishing")); // Magnifying Glass
        sidebar.add(Box.createRigidArea(new Dimension(0, 10)));
        sidebar.add(createSidebarBtn("OTP Generator \u23F1\uFE0F", "OTP")); // Stopwatch
        sidebar.add(Box.createRigidArea(new Dimension(0, 10)));
        sidebar.add(createSidebarBtn("Caesar Cipher \uD83D\uDD10", "Caesar")); // Lock and Key
        sidebar.add(Box.createRigidArea(new Dimension(0, 10)));
        sidebar.add(createSidebarBtn("Activity Log \uD83D\uDCDC", "Activity")); // Scroll

        sidebar.add(Box.createVerticalGlue());

        JButton logoutBtn = new JButton("Logout \uD83D\uDEAA"); // Door
        UIUtils.styleSidebarButton(logoutBtn);
        logoutBtn.setMaximumSize(new Dimension(250, 50));
        logoutBtn.addActionListener(e -> {
            ActivityLog.log("User Logged Out");
            dispose();
            new LoginScreen().setVisible(true);
        });
        sidebar.add(logoutBtn);

        add(sidebar, BorderLayout.WEST);
        add(contentPanel, BorderLayout.CENTER);
    }

    private JButton createSidebarBtn(String text, String cardName) {
        JButton btn = new JButton(text);
        UIUtils.styleSidebarButton(btn);
        btn.setMaximumSize(new Dimension(250, 50));
        btn.addActionListener(e -> {
            cardLayout.show(contentPanel, cardName);
        });
        return btn;
    }
}

package cybershield;

import javax.swing.*;
import java.awt.*;

public class LoadingScreen extends JFrame {
    private JProgressBar progressBar;

    public LoadingScreen() {
        setTitle("CyberShield - Loading");
        setSize(400, 300);
        setLocationRelativeTo(null);
        setUndecorated(true);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        JPanel panel = new JPanel(new BorderLayout());
        panel.setBackground(UIUtils.DARK_BG);
        panel.setBorder(BorderFactory.createLineBorder(UIUtils.PRIMARY_COLOR, 2));

        JLabel titleLabel = new JLabel("CyberShield Simulator", SwingConstants.CENTER);
        titleLabel.setFont(new Font("Segoe UI", Font.BOLD, 28));
        titleLabel.setForeground(UIUtils.PRIMARY_COLOR);
        
        JLabel subtitleLabel = new JLabel("Initializing Security Modules...", SwingConstants.CENTER);
        subtitleLabel.setFont(UIUtils.FONT_NORMAL);
        subtitleLabel.setForeground(UIUtils.DARK_FG);

        JPanel textPanel = new JPanel(new GridLayout(2, 1));
        textPanel.setOpaque(false);
        textPanel.add(titleLabel);
        textPanel.add(subtitleLabel);

        progressBar = new JProgressBar(0, 100);
        progressBar.setForeground(UIUtils.PRIMARY_COLOR);
        progressBar.setBackground(UIUtils.DARK_BG);
        progressBar.setStringPainted(true);
        progressBar.setBorderPainted(false);

        panel.add(textPanel, BorderLayout.CENTER);
        panel.add(progressBar, BorderLayout.SOUTH);
        add(panel);

        startLoading();
    }

    private void startLoading() {
        // Simulate loading process in a background thread
        new Thread(() -> {
            try {
                for (int i = 0; i <= 100; i += 5) {
                    Thread.sleep(100);
                    progressBar.setValue(i);
                }
                dispose(); // Close loading screen
                new LoginScreen().setVisible(true); // Open login screen
            } catch (Exception e) {
                e.printStackTrace();
            }
        }).start();
    }
}

package cybershield;

import javax.swing.*;
import java.awt.*;

public class PhishingDetectorPanel extends JPanel {
    public PhishingDetectorPanel() {
        setLayout(new BorderLayout());
        setBackground(UIUtils.DARK_BG);

        JLabel title = new JLabel("Phishing Link Detector");
        title.setFont(UIUtils.FONT_TITLE);
        title.setForeground(UIUtils.DARK_FG);
        title.setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));
        add(title, BorderLayout.NORTH);

        JPanel centerPanel = new JPanel(new GridBagLayout());
        centerPanel.setBackground(UIUtils.DARK_BG);
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(10, 10, 10, 10);
        gbc.fill = GridBagConstraints.HORIZONTAL;

        JLabel lbl = new JLabel("Enter URL or Message:");
        lbl.setForeground(UIUtils.DARK_FG);
        lbl.setFont(UIUtils.FONT_HEADING);
        gbc.gridx = 0; gbc.gridy = 0;
        centerPanel.add(lbl, gbc);

        JTextArea inputArea = new JTextArea(4, 30);
        inputArea.setFont(UIUtils.FONT_NORMAL);
        inputArea.setBackground(new Color(50, 50, 60));
        inputArea.setForeground(UIUtils.DARK_FG);
        inputArea.setCaretColor(UIUtils.DARK_FG);
        inputArea.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(UIUtils.PRIMARY_COLOR, 1),
                BorderFactory.createEmptyBorder(5, 10, 5, 10)
        ));
        inputArea.setLineWrap(true);
        gbc.gridx = 0; gbc.gridy = 1;
        centerPanel.add(new JScrollPane(inputArea), gbc);

        JButton scanBtn = new JButton("Scan for Phishing");
        UIUtils.styleButton(scanBtn, UIUtils.PRIMARY_COLOR);
        gbc.gridx = 0; gbc.gridy = 2;
        centerPanel.add(scanBtn, gbc);

        JLabel resultLbl = new JLabel("Status: ");
        resultLbl.setForeground(UIUtils.DARK_FG);
        resultLbl.setFont(UIUtils.FONT_TITLE);
        gbc.gridx = 0; gbc.gridy = 3;
        centerPanel.add(resultLbl, gbc);

        JTextArea reasonsArea = new JTextArea(5, 30);
        reasonsArea.setEditable(false);
        reasonsArea.setBackground(new Color(40, 40, 50));
        reasonsArea.setForeground(UIUtils.DARK_FG);
        reasonsArea.setFont(UIUtils.FONT_NORMAL);
        reasonsArea.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));
        gbc.gridx = 0; gbc.gridy = 4;
        centerPanel.add(new JScrollPane(reasonsArea), gbc);

        scanBtn.addActionListener(e -> {
            String text = inputArea.getText();
            scanText(text, resultLbl, reasonsArea);
            ActivityLog.log("Scanned text for phishing");
        });

        add(centerPanel, BorderLayout.CENTER);
    }

    private void scanText(String text, JLabel resultLbl, JTextArea reasonsArea) {
        String lowerText = text.toLowerCase();
        int dangerScore = 0;
        StringBuilder reasons = new StringBuilder("Analysis:\n");

        String[] suspiciousKeywords = {"free", "win", "urgent", "login now", "verify account", "click here", "claim"};
        for (String keyword : suspiciousKeywords) {
            if (lowerText.contains(keyword)) {
                dangerScore++;
                reasons.append("- Contains suspicious keyword: \"").append(keyword).append("\"\n");
            }
        }

        if (text.matches(".*\\d{5,}.*")) {
            dangerScore++;
            reasons.append("- URL contains unusually long sequence of numbers\n");
        }

        if (text.contains("@") && text.contains("http")) {
            dangerScore++;
            reasons.append("- URL contains '@' symbol (often used to obscure real domain)\n");
        }

        if (dangerScore == 0) {
            resultLbl.setText("Status: SAFE \u2705");
            resultLbl.setForeground(UIUtils.PRIMARY_COLOR);
            reasons.append("- No obvious phishing indicators found.");
        } else if (dangerScore == 1) {
            resultLbl.setText("Status: SUSPICIOUS \u26A0\uFE0F");
            resultLbl.setForeground(UIUtils.WARNING_COLOR);
            reasons.append("- Proceed with caution.");
        } else {
            resultLbl.setText("Status: DANGEROUS \uD83D\uDEA8");
            resultLbl.setForeground(UIUtils.DANGER_COLOR);
            reasons.append("- Highly likely to be a phishing attempt! DO NOT CLICK.");
        }
        
        reasonsArea.setText(reasons.toString());
    }
}

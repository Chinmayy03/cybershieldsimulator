package cybershield;

import javax.swing.*;
import java.awt.*;
import java.text.SimpleDateFormat;
import java.util.Date;

public class ActivityLog {
    private static JTextArea logArea;

    static {
        logArea = new JTextArea();
        logArea.setEditable(false);
        logArea.setFont(new Font("Consolas", Font.PLAIN, 14));
        logArea.setBackground(new Color(20, 20, 25));
        logArea.setForeground(new Color(0, 255, 0)); // Hacker green text
        logArea.setMargin(new Insets(10, 10, 10, 10));
    }

    public static void log(String activity) {
        String timestamp = new SimpleDateFormat("HH:mm:ss").format(new Date());
        logArea.append("[" + timestamp + "] " + activity + "\n");
    }

    public static JPanel getLogPanel() {
        JPanel panel = new JPanel(new BorderLayout());
        panel.setBackground(UIUtils.DARK_BG);
        
        JLabel title = new JLabel("Activity History");
        title.setFont(UIUtils.FONT_TITLE);
        title.setForeground(UIUtils.DARK_FG);
        title.setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));
        
        panel.add(title, BorderLayout.NORTH);
        
        JScrollPane scrollPane = new JScrollPane(logArea);
        scrollPane.setBorder(BorderFactory.createEmptyBorder(10, 20, 20, 20));
        scrollPane.getViewport().setBackground(UIUtils.DARK_BG);
        panel.add(scrollPane, BorderLayout.CENTER);
        
        return panel;
    }
}

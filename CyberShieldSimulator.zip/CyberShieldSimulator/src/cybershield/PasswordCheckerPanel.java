package cybershield;

import javax.swing.*;
import java.awt.*;

public class PasswordCheckerPanel extends JPanel {
    public PasswordCheckerPanel() {
        setLayout(new BorderLayout());
        setBackground(UIUtils.DARK_BG);

        JLabel title = new JLabel("Password Strength Checker");
        title.setFont(UIUtils.FONT_TITLE);
        title.setForeground(UIUtils.DARK_FG);
        title.setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));
        add(title, BorderLayout.NORTH);

        JPanel centerPanel = new JPanel(new GridBagLayout());
        centerPanel.setBackground(UIUtils.DARK_BG);
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(10, 10, 10, 10);
        gbc.fill = GridBagConstraints.HORIZONTAL;

        JLabel lbl = new JLabel("Enter Password:");
        lbl.setForeground(UIUtils.DARK_FG);
        lbl.setFont(UIUtils.FONT_HEADING);
        gbc.gridx = 0; gbc.gridy = 0;
        centerPanel.add(lbl, gbc);

        JTextField passField = new JTextField(20);
        UIUtils.styleTextField(passField);
        gbc.gridx = 0; gbc.gridy = 1;
        centerPanel.add(passField, gbc);

        JButton checkBtn = new JButton("Check Strength");
        UIUtils.styleButton(checkBtn, UIUtils.PRIMARY_COLOR);
        gbc.gridx = 0; gbc.gridy = 2;
        centerPanel.add(checkBtn, gbc);

        JLabel resultLbl = new JLabel("Strength: ");
        resultLbl.setForeground(UIUtils.DARK_FG);
        resultLbl.setFont(UIUtils.FONT_TITLE);
        gbc.gridx = 0; gbc.gridy = 3;
        centerPanel.add(resultLbl, gbc);

        JTextArea suggestions = new JTextArea(5, 30);
        suggestions.setEditable(false);
        suggestions.setBackground(new Color(40, 40, 50));
        suggestions.setForeground(UIUtils.DARK_FG);
        suggestions.setFont(UIUtils.FONT_NORMAL);
        suggestions.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));
        gbc.gridx = 0; gbc.gridy = 4;
        centerPanel.add(new JScrollPane(suggestions), gbc);

        checkBtn.addActionListener(e -> {
            String pwd = passField.getText();
            checkPassword(pwd, resultLbl, suggestions);
            ActivityLog.log("Checked password strength");
        });

        add(centerPanel, BorderLayout.CENTER);
    }

    private void checkPassword(String pwd, JLabel resultLbl, JTextArea suggestions) {
        boolean hasLower = pwd.matches(".*[a-z].*");
        boolean hasUpper = pwd.matches(".*[A-Z].*");
        boolean hasNum = pwd.matches(".*\\d.*");
        boolean hasSpecial = pwd.matches(".*[^a-zA-Z0-9].*");
        boolean isLong = pwd.length() >= 8;

        int score = 0;
        if (hasLower) score++;
        if (hasUpper) score++;
        if (hasNum) score++;
        if (hasSpecial) score++;
        if (isLong) score++;

        StringBuilder sugg = new StringBuilder("Suggestions:\n");
        if (!isLong) sugg.append("- Make it at least 8 characters long\n");
        if (!hasUpper) sugg.append("- Add uppercase letters\n");
        if (!hasLower) sugg.append("- Add lowercase letters\n");
        if (!hasNum) sugg.append("- Add numbers\n");
        if (!hasSpecial) sugg.append("- Add special characters (@, #, $)\n");

        if (score <= 2) {
            resultLbl.setText("Strength: WEAK \u274C");
            resultLbl.setForeground(UIUtils.DANGER_COLOR);
        } else if (score <= 4) {
            resultLbl.setText("Strength: MEDIUM \u26A0\uFE0F");
            resultLbl.setForeground(UIUtils.WARNING_COLOR);
        } else {
            resultLbl.setText("Strength: STRONG \u2705");
            resultLbl.setForeground(UIUtils.PRIMARY_COLOR);
            sugg.append("- Great password!");
        }
        suggestions.setText(sugg.toString());
    }
}

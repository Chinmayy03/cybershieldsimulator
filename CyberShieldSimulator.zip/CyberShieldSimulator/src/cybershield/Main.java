package cybershield;

import javax.swing.SwingUtilities;

public class Main {
    public static void main(String[] args) {
        // Start GUI on Event Dispatch Thread
        SwingUtilities.invokeLater(() -> {
            new LoadingScreen().setVisible(true);
        });
    }
}

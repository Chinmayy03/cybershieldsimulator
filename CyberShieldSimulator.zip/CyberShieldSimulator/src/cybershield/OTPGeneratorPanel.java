package cybershield;

import javax.swing.*;
import java.awt.*;
import java.awt.datatransfer.StringSelection;
import java.util.Random;

public class OTPGeneratorPanel extends JPanel {
    private JLabel otpLabel;
    private JLabel timerLabel;
    private Timer timer;
    private int timeLeft = 30;

    public OTPGeneratorPanel() {
        setLayout(new BorderLayout());
        setBackground(UIUtils.DARK_BG);

        JLabel title = new JLabel("OTP Generator");
        title.setFont(UIUtils.FONT_TITLE);
        title.setForeground(UIUtils.DARK_FG);
        title.setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));
        add(title, BorderLayout.NORTH);

        JPanel centerPanel = new JPanel();
        centerPanel.setBackground(UIUtils.DARK_BG);
        centerPanel.setLayout(new BoxLayout(centerPanel, BoxLayout.Y_AXIS));
        
        // OTP Card Panel
        JPanel cardPanel = new JPanel();
        cardPanel.setBackground(new Color(40, 40, 50));
        cardPanel.setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createLineBorder(UIUtils.PRIMARY_COLOR, 2),
            BorderFactory.createEmptyBorder(30, 50, 30, 50)
        ));
        cardPanel.setMaximumSize(new Dimension(400, 200));

        otpLabel = new JLabel("------");
        otpLabel.setFont(new Font("Monospaced", Font.BOLD, 48));
        otpLabel.setForeground(UIUtils.PRIMARY_COLOR);
        otpLabel.setAlignmentX(Component.CENTER_ALIGNMENT);
        cardPanel.add(otpLabel);
        
        timerLabel = new JLabel("Expires in: 30s");
        timerLabel.setFont(UIUtils.FONT_HEADING);
        timerLabel.setForeground(UIUtils.WARNING_COLOR);
        timerLabel.setAlignmentX(Component.CENTER_ALIGNMENT);

        centerPanel.add(Box.createRigidArea(new Dimension(0, 50)));
        centerPanel.add(cardPanel);
        centerPanel.add(Box.createRigidArea(new Dimension(0, 20)));
        centerPanel.add(timerLabel);
        centerPanel.add(Box.createRigidArea(new Dimension(0, 30)));

        JPanel btnPanel = new JPanel(new FlowLayout());
        btnPanel.setBackground(UIUtils.DARK_BG);

        JButton generateBtn = new JButton("Generate OTP");
        UIUtils.styleButton(generateBtn, UIUtils.PRIMARY_COLOR);
        
        JButton copyBtn = new JButton("Copy OTP");
        UIUtils.styleButton(copyBtn, new Color(33, 150, 243));

        btnPanel.add(generateBtn);
        btnPanel.add(copyBtn);

        centerPanel.add(btnPanel);
        add(centerPanel, BorderLayout.CENTER);

        timer = new Timer(1000, e -> {
            timeLeft--;
            timerLabel.setText("Expires in: " + timeLeft + "s");
            if (timeLeft <= 0) {
                timer.stop();
                otpLabel.setText("------");
                otpLabel.setForeground(UIUtils.DANGER_COLOR);
                timerLabel.setText("OTP Expired!");
                timerLabel.setForeground(UIUtils.DANGER_COLOR);
            }
        });

        generateBtn.addActionListener(e -> generateOTP());
        copyBtn.addActionListener(e -> {
            if (!otpLabel.getText().equals("------") && timeLeft > 0) {
                Toolkit.getDefaultToolkit().getSystemClipboard()
                       .setContents(new StringSelection(otpLabel.getText()), null);
                JOptionPane.showMessageDialog(this, "OTP Copied to Clipboard!");
                ActivityLog.log("OTP copied");
            }
        });
    }

    private void generateOTP() {
        Random rand = new Random();
        int otp = 100000 + rand.nextInt(900000); // 6-digit number
        otpLabel.setText(String.valueOf(otp));
        otpLabel.setForeground(UIUtils.PRIMARY_COLOR);
        
        timeLeft = 30;
        timerLabel.setText("Expires in: 30s");
        timerLabel.setForeground(UIUtils.WARNING_COLOR);
        
        timer.restart();
        Toolkit.getDefaultToolkit().beep(); // Sound effect
        ActivityLog.log("Generated new OTP");
    }
}

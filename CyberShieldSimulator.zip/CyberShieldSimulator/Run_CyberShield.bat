@echo off
title CyberShield Simulator Launcher
cd /d "%~dp0"
echo Starting CyberShield Simulator...
java -cp bin cybershield.Main
